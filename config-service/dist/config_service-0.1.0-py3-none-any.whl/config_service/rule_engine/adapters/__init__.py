"""Built-in rule adapters."""
